import time
import json
import praw
import random

def underline_text(string):
    return '\u0332'.join(string)

class BaseRedditBot:
    def __init__(self) -> None:
        self.s = self.loadState()

        self.username = self.s["username"]
        self.password = self.s["password"]
        self.client_id = self.s["client_id"]
        self.client_secret = self.s["client_secret"]
        self.user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36"

        self.r = praw.Reddit(
            username=self.username,
            password=self.password,
            client_id=self.client_id,
            client_secret=self.client_secret,
            user_agent=self.user_agent
        )
        self.r.validate_on_submit = True
        print("REDDIT ACCOUNT LOGGED IN")

    def sleepRandom(self, rangeStart, rangeEnd, denominator=1):
        sleepTime = random.randint(rangeStart, rangeEnd)/denominator
        print(f"Sleeping for {sleepTime}")
        time.sleep(sleepTime)

    def loadState(self):
        with open('data/state.json', 'r') as file:
            state = json.load(file)
        return state

    def saveState(self, updatedValues={}, save_state=True):
        for key in updatedValues:
            self.s[key] = updatedValues[key]
        if save_state:
            with open('data/state.json', 'w') as file:
                json.dump(self.s, file)


class RedditBot(BaseRedditBot):

    def parseComment(self, keyword_index: int, comment_body_list: list) -> str:
        full_string = []
        comment_body_list[keyword_index] = underline_text(comment_body_list[keyword_index])
        if keyword_index > 10:
            full_string += comment_body_list[keyword_index - 10:keyword_index]
        else:
            full_string = comment_body_list[:keyword_index]
        full_string += comment_body_list[keyword_index : keyword_index + 11]
        comment_body:str = " ".join(full_string)
        return comment_body


    def handleComment(self, comment):
        comment_body_list = comment.body.lower().split(" ")
        
        for keyword in self.s["keywords"]:
            if (keyword in comment_body_list):
                keyword_index = comment_body_list.index(keyword)
                return {
                    "author":comment.author.name,
                    "body":self.parseComment(keyword_index, comment.body.split(" ")),
                    "id":comment.id,
                    "keyword":keyword
                }

        return False

    def getNewComments(self, subreddit):
        comments_container = []
        for comment in self.r.subreddit(subreddit).comments(limit=None):
            if "Erl-X" in comment.author.name:
                print("-->", comment.link_id, "-->", comment.permalink)
            t = (time.time() - comment.created_utc)/60
            if (t >= self.s["minutes"]):
                break
            
            if (comment.author.name in self.s["blacklist"]):
                continue
            
            parsed_comment = self.handleComment(comment)
            if parsed_comment:
                comments_container.append(parsed_comment)
            
        return comments_container

    def getCommentsFromSubreddits(self):
        comments_container = []
        for subreddit in self.s["subreddits"]:
            new_comments = [comment for comment in self.getNewComments(subreddit) if comment not in self.s["filtered_comments"]]
            comments_container.extend(new_comments)
            print(f"Comments Extracted from Subreddit:{subreddit} Comments Count:{len(new_comments)}" )
        
        self.s["filtered_comments"].extend(comments_container)
        self.saveState()

    def parseMessage(self, author_name):
        subject = self.s["subject"].replace("{{author}}", author_name)
        message = self.s["message"].replace("{{author}}", author_name)
        return subject, message

    def sendInvitesToCommentors(self):
        for comment in self.s["filtered_comments"][:]:
            subject, message = self.parseMessage(comment["author"])
            
            if comment["author"] not in self.s["blacklist"]:
                try:
                    self.r.redditor(comment["author"]).message(subject, message)
                    print(f"Message sent to: {comment['author']}")
                    self.s["blacklist"].append(comment["author"])
                except Exception as e:
                    print(f"Error sending message to: {comment['author']}", e)
                
                time.sleep(self.s["sleep_after_message"])
            
            self.s["filtered_comments"].remove(comment)
            self.saveState()
