import tkinter
from tkinter.scrolledtext import ScrolledText
from functools import partial
from main import RedditBot

#################### WIDGET FUNCTIONS ####################


class BaseApplication:

    def __init__(self, master, master_row, master_column) -> None:

        self.master = tkinter.Frame(master)
        self.master.grid(row=master_row, column=master_column)
    
    def Label(self, text, width, row, column):
        label = tkinter.Label(self.master, text=text, width=width)
        label.grid(row=row, column=column)
        return label

    def Message(self, text, width, row, column):
        message = tkinter.Message(self.master, text=text, width=width)
        message.grid(row=row, column=column)
        return message

    def Button(self, text, width, row, column, command=None, disabled=False, container=None):

        button = tkinter.Button(container if container else self.master, text=text, width=width, command=command)
        if disabled:
            button["state"] = "disabled"
        button.grid(row=row, column=column)
        return button


    def Entry(self, text, width, row, column):
        entry = tkinter.Entry(self.master, width=width)
        entry.insert(0, text)
        entry.grid(row=row, column=column)
        return entry


    def TextBox(self, text, width, height, row, column):
        textBox = ScrolledText(self.master, width=width, height=height)
        textBox.insert('1.0', text)
        textBox.grid(row=row, column=column)
        return textBox


    def Frame(self, row, column, columnspan=None):
        frame = tkinter.Frame(self.master)
        frame.grid(row=row, column=column, columnspan=columnspan)
        return frame
    
    def Canvas(self, row, column):
        canvas = tkinter.Canvas(self.master)
        canvas.grid(row=row, column=column)
        return canvas
    
    def getListFromTextBox(self, textbox, split_data=True, split_at="\n", is_int=False, is_bool=False, func=None):
        data_container = []
        raw_data = textbox.get('1.0', 'end-1c').strip()
        if not split_data:
            return raw_data
        for data in raw_data.split(split_at):
            if not data.strip():
                continue
            if is_int:
                data = int(data)
            if is_bool:
                data = True if data.lower() == "true" else False
            if func:
                data = func(data)
            data_container.append(data)

        return data_container

    def getDataFromEntry(self, entry, is_int=False, is_bool=False, func=None):
        data = entry.get().strip()
        if is_int:
            data = int(data)
        if is_bool:
            data = True if data.lower() == "true" else False
        if func:
            data = func(data)
        return data


    def createInput(self, label, text, row, is_textbox=False, join_with="\n"):
        self.Label(label, 20, row, 0)
        if not is_textbox:
            return self.Entry(text, 40, row, 1)
        else:
            if isinstance(text, list):
                text = join_with.join([str(data) for data in text])
            return self.TextBox(text, 40, 7, row, 1)


    def retrieveEntries(**kwargs):
        entriesObj = {}
        for entry in kwargs:
            try:
                entriesObj[entry] = kwargs[entry].get().strip()
            except:
                entriesObj[entry] = kwargs[entry].get('1.0', 'end-1c').strip()
        return entriesObj


class TableBaseApplication(BaseApplication):
    def __init__(self, master, master_row, master_column, table_data, display_keys, func_container) -> None:
        super().__init__(master, master_row, master_column)
        self.table_data = table_data
        self.display_keys = display_keys
        self.func_container = func_container

    def loadTableData(self):
        for _ in self.master.winfo_children():
            _.destroy()

        row = 0
        for table_data in self.table_data:
            column = 0
            for key in self.display_keys:
                self.Label(table_data[key], 25, row, column)
                column += 1
            for func_data in self.func_container:
                self.Button(func_data["label"], 20, row, column, partial(func_data["command"], table_data))
                column += 1
            row += 1
               

######################################################################################################################

class NavBarWidget(BaseApplication):
    def __init__(self, master, master_row, master_column, btn_configuration) -> None:
        super().__init__(master, master_row, master_column)
        
        column = 0
        for btn in btn_configuration:
            self.Button(btn["name"], 25, 0, column, btn["command"])
            column += 1
    

class SettingWidget(BaseApplication):

    def __init__(self, master, master_row, master_column, state, saveStateFunc) -> None:
        super().__init__(master, master_row, master_column)
        self.s = state
        self.saveState = saveStateFunc

        self.username = self.createInput('Username', self.s["username"], 0)
        self.password = self.createInput('password', self.s["password"], 1)
        self.client_id = self.createInput('client_id', self.s["client_id"], 2)
        self.client_secret = self.createInput('client_secret', self.s["client_secret"], 3)
        self.subreddits = self.createInput('Subreddits', self.s["subreddits"], 4, is_textbox=True)
        self.subject = self.createInput('Subject', self.s["subject"], 5)
        self.message = self.createInput('Message', self.s["message"], 6, is_textbox=True)
        self.sleep_after_message = self.createInput('Sleep After Message', self.s["sleep_after_message"], 7)
        self.minutes = self.createInput('Minutes', self.s["minutes"], 8)
        self.keywords = self.createInput('Keywords', self.s["keywords"], 9, is_textbox=True)
        self.blacklist = self.createInput('Blacklist', self.s["blacklist"], 10, is_textbox=True)
        self.Button('Save Settings', 20, 20, 0, self.updateState)
    
    def updateState(self):
        self.s["username"] = self.getDataFromEntry(self.username)
        self.s["password"] = self.getDataFromEntry(self.password)
        self.s["client_id"] = self.getDataFromEntry(self.client_id)
        self.s["client_secret"] = self.getDataFromEntry(self.client_secret)
        self.s["subreddits"] = self.getListFromTextBox(self.subreddits)
        self.s["subject"] = self.getDataFromEntry(self.subject)
        self.s["message"] = self.getListFromTextBox(self.message, split_data=False)
        self.s["sleep_after_message"] = self.getDataFromEntry(self.sleep_after_message, is_int=True)
        self.s["minutes"] = self.getDataFromEntry(self.minutes, is_int=True)
        self.s["keywords"] = self.getListFromTextBox(self.keywords)
        self.s["blacklist"] = self.getListFromTextBox(self.blacklist)
        self.saveState()


class FilterCommentWidget(BaseApplication):
    def __init__(self, master, master_row, master_column, state, saveState) -> None:
        super().__init__(master, master_row, master_column)
        self.s = state
        self.table_data = self.s["filtered_comments"]
        self.saveState = saveState
        self.offset = 0
        self.page_num = 0
        self.limit = 10
        self.loadTableData()

    def loadPagination(self):
        def update_page(page_num):
            self.page_num = page_num
            self.offset = page_num * self.limit
            self.loadTableData()

        pagination_container = self.Frame(0, 0, 3)
        page_count = len(self.table_data)/self.limit
        page_count = int(page_count) + (1 if page_count != int(page_count) else 0)
        btns_needed = 10
        if (self.page_num - 5) > 0:
            page_num_start = self.page_num - 5
        else:
            page_num_start = 0
        
        page_num_end = page_num_start + btns_needed
        if page_num_end > page_count:
            page_num_end = page_count
        
        if self.page_num - 1 >= 0:
            self.Button("<-", 5, 0, 0, partial(update_page, self.page_num - 1), container=pagination_container)
        if self.page_num + 2 <= page_count:
            self.Button("->", 5, 0, 1, partial(update_page, self.page_num + 1), container=pagination_container)
        column = 2
        for page_num in range(page_num_start, page_num_end):
            disabled_btn = False
            if page_num == self.page_num:
                disabled_btn = True
            self.Button(page_num, 5, 0, column, partial(update_page, page_num), container=pagination_container, disabled=disabled_btn)
            column += 1
        


    def loadTableData(self):
        for _ in self.master.winfo_children():
            _.destroy()
        
        self.loadPagination()
        row=1
        for data in self.table_data[self.offset:self.offset + self.limit]:
            self.Label(data["author"], 25, row, 0)
            self.TextBox(data["body"], 70, 4, row, 1)
            self.Button("Delete", 20, row, 3, partial(self.removeTableData, data))
            row+=1

    def removeTableData(self, data):
        self.table_data.remove(data)
        self.saveState()
        if self.offset == len(self.table_data):
            self.offset - self.limit
        self.page_num - 1
        self.loadTableData()

class RootWidget(BaseApplication):
    def __init__(self, master, master_row, master_column) -> None:
        super().__init__(master, master_row, master_column)
        self.r = RedditBot()

        self.main_frame = None
        self.configureNavBar()

    def changeFrameContent(self, content_class, *args):
        if self.main_frame:
            self.main_frame.destroy()
        self.main_frame = self.Frame(1, 0)
        content_class(self.main_frame, 0, 0, *args)

    def configureNavBar(self):
        btn_configuration = [
            {"name": "Settings", "command": partial(self.changeFrameContent, SettingWidget, self.r.s, self.r.saveState)},
            {"name": "Comments", "command": partial(self.changeFrameContent, FilterCommentWidget, self.r.s, self.r.saveState)},
            {"name": "Get Comments", "command": partial(self.r.getCommentsFromSubreddits)},
            {"name": "Send Invites", "command": partial(self.r.sendInvitesToCommentors)}
        ]
        self.navbar = NavBarWidget(self.master, 0, 0, btn_configuration)
    

    

if __name__ == "__main__":
    root = tkinter.Tk()
    RootWidget(root, 0, 0)
    root.mainloop()
